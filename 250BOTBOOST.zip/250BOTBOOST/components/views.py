import json
import os
import discord
from discord.ext import commands
from dotenv import load_dotenv
import config

# โหลด .env ก่อนอ่านค่าอิโมจิ (views.py ถูก import ก่อน main.py เรียก load_dotenv)
load_dotenv()
from .modals import BoostOrderModal

class BoostSelectDropdown(discord.ui.Select):
    def __init__(self, bot_instance: commands.Bot, api_client, helpers: dict):
        self.bot = bot_instance
        self.api_client = api_client
        self.helpers = helpers
        options = [
            discord.SelectOption(label="บูสต์ 1 เดือน", value="1", description="สั่งซื้อบูสต์เซิร์ฟเวอร์แบบ 1 เดือน", emoji="<a:245_boost:1175394139504910336>"),
            discord.SelectOption(label="บูสต์ 3 เดือน", value="3", description="สั่งซื้อบูสต์เซิร์ฟเวอร์แบบ 3 เดือน", emoji="<:3m:1560221310825799700> "),
        ]
        super().__init__(
            placeholder="[ 📦 เลือกประเภทบูสต์เซิร์ฟเวอร์ ]",
            min_values=1,
            max_values=1,
            options=options,
            custom_id="og_shop_dropdown_select_boost"
        )

    async def callback(self, interaction: discord.Interaction):
        month = int(self.values[0])
        try:
            new_view = BoostPanelView(bot_instance=self.bot, api_client=self.api_client, helpers=self.helpers)
            await interaction.message.edit(view=new_view)
        except Exception as e:
            print(f"[Reset Dropdown Warning]: {e}")

        await interaction.response.send_modal(
            BoostOrderModal(month=month, bot_instance=self.bot, api_client=self.api_client, helpers=self.helpers)
        )

class BoostPanelView(discord.ui.View):
    def __init__(self, bot_instance: commands.Bot, api_client, helpers: dict):
        super().__init__(timeout=None)
        self.helpers = helpers
        
        # 1. Dropdown เลือกประเภทบูสต์ (แถว 0)
        self.add_item(BoostSelectDropdown(bot_instance=bot_instance, api_client=api_client, helpers=helpers))
        
        # 2. เพิ่มปุ่มลิงก์คลิปสอนใช้งานผ่าน add_item (แถว 1)
        self.add_item(
            discord.ui.Button(
                label="⦅ คลิปสอนใช้งาน ⦆",
                emoji="<:botsever6:1184837744611049512>",
                style=discord.ButtonStyle.link,
                url="https://www.youtube.com/watch?v=iuqBl7gtncU",
                row=1
            )
        )

    @discord.ui.button(label="⦅ เช็คยอดเงิน ⦆", style=discord.ButtonStyle.primary, emoji="💵", row=1, custom_id="og_shop_btn_balance")
    async def balance_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        try:
            with open(config.PATHDB, 'r', encoding='utf-8') as f:
                userJSON = json.load(f)
        except Exception:
            userJSON = {}

        user_id_str = str(interaction.user.id)
        if user_id_str not in userJSON:
            embed = discord.Embed(description='🏦﹒เติมเงินเพื่อเปิดบัญชี', color=discord.Color.red())
        else:
            embed = discord.Embed(
                description=f'💳﹒ยอดเงินคงเหลือ **__{userJSON[user_id_str]["point"]}__** บาท',
                color=discord.Color.green()
            )
        await interaction.response.send_message(embed=embed, ephemeral=True)

    @discord.ui.button(label="⦅ วิธีใช้งาน ⦆", style=discord.ButtonStyle.secondary, emoji=os.getenv("EMOJI_BTN_TUTORIAL", "<a:245_boost:1175394139504910336>"), row=1, custom_id="og_shop_btn_guide")
    async def guide_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        embed = discord.Embed(title="📒 อ่านเงื่อนไขสำหรับการบูสต์",color=discord.Color.from_rgb(47, 49, 54))
        embed.add_field(name="คำแนะนำ",value="```\nโปรดปิดระบบป้องกันการเข้าเซิร์ฟเวอร์ชั่วคราวก่อนเริ่มบูสต์\nทางร้านจำหน่ายเฉพาะจำนวนคู่\n🛠️พบปัญหาหรือเติมเงินไม่ได้? สามารถแจ้งทีมงานได้ที่ ticket \n ```",inline=False)
        await interaction.response.send_message(embed=embed, ephemeral=True)