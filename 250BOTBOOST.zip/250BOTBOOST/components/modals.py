import json
import asyncio
import datetime
import discord
from discord.ext import commands
import config

class BoostOrderModal(discord.ui.Modal):
    def __init__(self, month: int, bot_instance: commands.Bot, api_client, helpers: dict):
        super().__init__(title=f"สั่งซื้อบูสต์ {month} เดือน", custom_id=f"modal_boost_order_{month}")
        self.month = month
        self.bot = bot_instance
        self.api_client = api_client
        self.helpers = helpers

        self.invite_input = discord.ui.TextInput(
            label="ลิงก์เชิญเซิร์ฟเวอร์ Discord",
            placeholder="https://discord.gg/xxxxxx",
            required=True,
            custom_id="modal_input_invite"
        )
        self.amount_input = discord.ui.TextInput(
            label="จำนวนบูสต์ที่ต้องการ (เม็ด เลขคู่)",
            placeholder="2, 4, 6, 8, 10, 14",
            required=True,
            max_length=4,
            custom_id="modal_input_amount"
        )
        self.add_item(self.invite_input)
        self.add_item(self.amount_input)

    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        user_id_str = str(interaction.user.id)

        try:
            amount = int(self.amount_input.value.strip())
            if amount <= 0:
                raise ValueError
        except ValueError:
            await interaction.followup.send("❌ กรุณาระบุจำนวนเป็นตัวเลขจำนวนเต็มที่มากกว่า 0", ephemeral=True)
            return

        price_per_unit = float(self.helpers["custom_price_1m"] if self.month == 1 else self.helpers["custom_price_3m"])
        total_price = price_per_unit * amount

        try:
            with open(config.PATHDB, 'r', encoding='utf-8') as f:
                db_data = json.load(f)
        except Exception as e:
            await interaction.followup.send(f"❌ โหลดฐานข้อมูลไม่สำเร็จ: {e}", ephemeral=True)
            return

        if user_id_str not in db_data:
            await interaction.followup.send("❌ ไม่พบบัญชีของคุณในระบบ กรุณาเติมเงินเพื่อเปิดบัญชีก่อนทำรายการ", ephemeral=True)
            return

        user_points = float(db_data[user_id_str].get("point", 0))
        if user_points < total_price:
            await interaction.followup.send(
                f"❌ ยอดเงินของคุณไม่เพียงพอ!\n- ราคารวม: `{total_price:.2f}` บาท\n- ยอดคงเหลือ: `{user_points:.2f}` บาท", 
                ephemeral=True
            )
            return

        # หักเงินก่อนเริ่ม
        db_data[user_id_str]["point"] = f"{(user_points - total_price):.2f}"
        with open(config.PATHDB, 'w', encoding='utf-8') as f:
            json.dump(db_data, f, ensure_ascii=False, indent=4)

        invite_link = self.invite_input.value.strip()
        res = await self.api_client.buy_boost(invite_link=invite_link, month=self.month, amount=amount)
        order_id = res.get("oders_id") or res.get("orderId")

        if not order_id:
            # คืนเงินถ้าสร้างออเดอร์ไม่สำเร็จ
            db_data[user_id_str]["point"] = f"{user_points:.2f}"
            with open(config.PATHDB, 'w', encoding='utf-8') as f:
                json.dump(db_data, f, ensure_ascii=False, indent=4)
            msg = res.get("message", "สต็อกไม่พอหรือระบบขัดข้อง")
            await interaction.followup.send(f"❌ ทำรายการไม่สำเร็จ (ระบบคืนเงินแล้ว): {msg}", ephemeral=True)
            return

        status_embed = discord.Embed(
            title="⏳ กำลังดำเนินการบูสต์เซิร์ฟเวอร์",
            description="ระบบได้รับออเดอร์แล้วและกำลังส่งบูสต์เข้าสู่เซิร์ฟเวอร์...",
            color=discord.Color.blue()
        )
        status_embed.add_field(name="Order ID", value=f"`{order_id}`", inline=True)
        status_embed.add_field(name="จำนวน", value=f"`{amount}` เม็ด ({self.month} เดือน)", inline=True)
        status_embed.add_field(name="ยอดเงินคงเหลือ", value=f"`{float(db_data[user_id_str]['point']):.2f}` บาท", inline=True)
        status_embed.add_field(name="สถานะปัจจุบัน", value="`รอคิว / กำลังดำเนินการ...`", inline=False)
        
        status_msg = await interaction.followup.send(embed=status_embed, ephemeral=True)

        log_channel = None
        if self.helpers.get("log_channel_id"):
            log_channel = self.bot.get_channel(int(self.helpers["log_channel_id"]))

        retry_count = 0
        max_retries = 60  # วนตรวจสูงสุด 5 นาที (60 * 5 วิ) ป้องกันลูปค้างถาวร

        while retry_count < max_retries:
            await asyncio.sleep(5)
            retry_count += 1
            try:
                hist = await self.api_client.get_order_history(order_id)
                data = hist.get("data", {}) if isinstance(hist, dict) else {}
                status = str(hist.get("status") or data.get("status", "")).lower()

                # กรณีออเดอร์ยกเลิก/ล้มเหลว
                if status in ["failed", "cancelled", "rejected", "error"]:
                    with open(config.PATHDB, 'r', encoding='utf-8') as f:
                        current_db = json.load(f)
                    refund_pt = float(current_db[user_id_str].get('point', 0)) + total_price
                    current_db[user_id_str]["point"] = f"{refund_pt:.2f}"
                    current_db[user_id_str]["transaction"].append({
                        "refund": {
                            "name": "คืนเงินบูสต์ไม่สำเร็จ",
                            "order_id": order_id,
                            "amount": total_price,
                            "time": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                        }
                    })
                    with open(config.PATHDB, 'w', encoding='utf-8') as f:
                        json.dump(current_db, f, ensure_ascii=False, indent=4)

                    await status_msg.edit(embed=discord.Embed(title="❌ การบูสต์ล้มเหลว (ระบบคืนเงินเต็มจำนวนแล้ว)", color=discord.Color.red()))
                    break

                order_id_real = data.get("orderId", order_id)
                success_count = int(data.get("boostSuccess", 0))
                req_amount = int(data.get("boostAmount", amount))
                
                guild_info = data.get("guildInfo") or {}
                guild_name = guild_info.get("guildName", "ไม่ทราบชื่อเซิร์ฟเวอร์")
                guild_icon = guild_info.get("guildIcon")

                boost_before_val = int(guild_info.get("boostCountBefore") or 0)
                boost_after_raw = int(guild_info.get("boostCountAfter") or 0)

                if boost_after_raw <= boost_before_val and success_count > 0:
                    boost_after_val = boost_before_val + success_count
                else:
                    boost_after_val = boost_after_raw

                if status == "completed":
                    missing_count = req_amount - success_count
                    refund_amount = 0.0

                    if missing_count > 0:
                        refund_amount = missing_count * price_per_unit
                        with open(config.PATHDB, 'r', encoding='utf-8') as f:
                            current_db = json.load(f)
                        updated_point = float(current_db[user_id_str].get("point", 0)) + refund_amount
                        current_db[user_id_str]["point"] = f"{updated_point:.2f}"
                        current_db[user_id_str]["transaction"].append({
                            "refund": {
                                "name": "คืนเงินบูสต์ไม่ครบจำนวน",
                                "order_id": order_id_real,
                                "amount": refund_amount,
                                "time": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                            }
                        })
                        with open(config.PATHDB, 'w', encoding='utf-8') as f:
                            json.dump(current_db, f, ensure_ascii=False, indent=4)

                    if success_count > 0:
                        self.helpers["add_boost_stats"](self.month, success_count)

                    with open(config.PATHDB, 'r', encoding='utf-8') as f:
                        final_db = json.load(f)
                    final_user_point = float(final_db[user_id_str].get("point", 0))

                    if success_count == req_amount:
                        res_title = "✅ บูสต์เซิร์ฟเวอร์สำเร็จเรียบร้อย!"
                        embed_color = discord.Color.green()
                    elif success_count > 0:
                        res_title = "⚠️ บูสต์สำเร็จบางส่วน (คืนเงินส่วนที่ขาดแล้ว)"
                        embed_color = discord.Color.gold()
                    else:
                        res_title = "❌ บูสต์ไม่สำเร็จ (ระบบคืนเงินเต็มจำนวนแล้ว)"
                        embed_color = discord.Color.red()

                    done_embed = discord.Embed(title=res_title, color=embed_color)
                    done_embed.add_field(name="Order ID", value=f"`{order_id_real}`", inline=True)
                    done_embed.add_field(name="เซิร์ฟเวอร์", value=f"**{guild_name}**", inline=True)
                    done_embed.add_field(name="บูสต์สำเร็จ", value=f"`{success_count}/{req_amount}` เม็ด", inline=True)
                    done_embed.add_field(name="ระดับบูสต์เซิร์ฟ", value=f"`{boost_before_val} ➜ {boost_after_val}` เม็ด", inline=True)

                    if missing_count > 0:
                        done_embed.add_field(
                            name="💰 ยอดเงินคืนเข้าบัญชี", 
                            value=f"คืนเงิน `{refund_amount:.2f}` บาท (ไม่เข้า `{missing_count}` เม็ด)\nยอดเงินคงเหลือ: `{final_user_point:.2f}` บาท", 
                            inline=False
                        )
                    done_embed.set_footer(text="ขอบคุณที่ใช้บริการครับ")

                    await status_msg.edit(embed=done_embed)
                    await self.helpers["update_main_panel"](self.bot)

                    if log_channel:
                        log_embed = discord.Embed(
                            title="✨ทำรายการบูสต์เสร็จสิ้น (ORDER COMPLETED)✨",
                            description="```fix\nระบบได้ดำเนินการส่งบูสต์และสรุปยอดคงเหลือเรียบร้อยแล้ว\n```",
                            color=discord.Color.from_rgb(87, 242, 135) if missing_count == 0 else discord.Color.orange(),
                            timestamp=discord.utils.utcnow()
                        )
                        if guild_icon:
                            log_embed.set_thumbnail(url=guild_icon)
                        elif interaction.user.display_avatar:
                            log_embed.set_thumbnail(url=interaction.user.display_avatar.url)

                        log_embed.add_field(name="👤 ผู้ทำรายการ", value=f"{interaction.user.mention}`ID: {user_id_str}`", inline=False)
                        log_embed.add_field(name="🌐 เซิร์ฟเวอร์เป้าหมาย", value=f"``\n{guild_name}\n```", inline=False)
                        log_embed.add_field(name="💎 แพ็กเกจที่เลือก", value=f"```fix\n{self.month} เดือน\n```", inline=True)
                        log_embed.add_field(name="🚀 บูสต์ที่เข้าจริง", value=f"```fix\n{success_count}/{req_amount} เม็ด\n```", inline=True)
                        log_embed.add_field(name="📊 ระดับบูสต์เซิร์ฟ", value=f"```fix\n{boost_before_val} ➜ {boost_after_val}` เม็ด\n```", inline=True)
                        log_embed.add_field(name="🧾 รหัสคำสั่งซื้อ (Order ID)", value=f"`{order_id_real}`", inline=True)

                        if missing_count > 0:
                            log_embed.add_field(name="⚠️ คืนเงินส่วนต่าง", value=f"`+{refund_amount:.2f}` บาท (`{missing_count}` เม็ด)", inline=True)

                        log_embed.add_field(name="💰 ยอดเงินคงเหลือ", value=f"`{final_user_point:.2f} บาท`", inline=True)
                        log_embed.set_footer(text="NOm_Na0", icon_url="https://postimg.cc/BjvjkL0H")

                        await log_channel.send(embed=log_embed)
                    break
                else:
                    if len(status_embed.fields) >= 4:
                        status_embed.set_field_at(
                            3, 
                            name="สถานะปัจจุบัน", 
                            value=f"`กำลังส่งบูสต์... ({success_count}/{req_amount} เม็ด)`", 
                            inline=False
                        )
                        await status_msg.edit(embed=status_embed)

            except Exception as loop_err:
                print(f"[Polling Warning] Order: {order_id} | {loop_err}")