import os
import json
import asyncio
import datetime
import aiohttp
import cv2
import numpy as np
import discord
from discord import app_commands
from discord.ext import commands
from dotenv import load_dotenv
## from cogs.topup_and_admin import TopupPanelButtonView
import config

load_dotenv()

# ดึงค่า Emojis และการตั้งค่าจาก .env
EMOJI_POINT = os.getenv("EMOJI_POINT", "🪙")
EMOJI_SUCCESS = os.getenv("EMOJI_SUCCESS", "✅")
EMOJI_FAIL = os.getenv("EMOJI_FAIL", "❌")
EMOJI_WAIT = os.getenv("EMOJI_WAIT", "⏳")
EMOJI_BANK = os.getenv("EMOJI_BANK", "🏦")
EMOJI_GIFT = os.getenv("EMOJI_GIFT", "🧧")
EMOJI_BOOST = os.getenv("EMOJI_BOOST", "<:3m:1560221310825799700> ")

PLANARIA_API_KEY = os.getenv("PLANARIA_API_KEY", "")
TRUEMONEY_PHONE = os.getenv("TRUEMONEY_PHONE", "")
CHANNEL_SCAN_QR = int(os.getenv("CHANNEL_SCAN_QR", "0"))
TOPUP_LOG_CHANNEL_ID = int(os.getenv("TOPUP_LOG_CHANNEL_ID", "0"))
RECEIVER_NAME_CHECK = os.getenv("RECEIVER_NAME_CHECK", "")

ALLOWED_ADMIN_IDS = [
    int(x.strip()) for x in os.getenv("ALLOWED_ADMIN_IDS", "").split(",") if x.strip().isdigit()
]

BANK_QR_IMAGE_URL = os.getenv("BANK_QR_IMAGE_URL", "")
BANK_ACCOUNT_NAME = os.getenv("BANK_ACCOUNT_NAME", "")
BANK_ACCOUNT_NUMBER = os.getenv("BANK_ACCOUNT_NUMBER", "")
BANK_NAME = os.getenv("BANK_NAME", "")

# --- ฟังก์ชันจัดการฐานข้อมูล users.json ---
def get_user_db():
    if not os.path.exists(config.PATHDB):
        os.makedirs(os.path.dirname(config.PATHDB), exist_ok=True)
        with open(config.PATHDB, "w", encoding="utf-8") as f:
            json.dump({}, f, indent=4)
        return {}
    with open(config.PATHDB, "r", encoding="utf-8") as f:
        return json.load(f)

def save_user_db(data):
    with open(config.PATHDB, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=4)

def update_user_balance(user_id: int, amount: float, tx_data: dict = None):
    db = get_user_db()
    uid = str(user_id)
    if uid not in db:
        db[uid] = {
            "userId": user_id,
            "point": "0.0",
            "all-point": "0.0",
            "historybuy": [],
            "transaction": [],
            "buyrole": [],
            "buymarket": []
        }
    current_pt = float(db[uid].get("point", 0))
    all_pt = float(db[uid].get("all-point", 0))
    
    new_pt = current_pt + amount
    db[uid]["point"] = f"{new_pt:.2f}"
    
    if amount > 0:
        db[uid]["all-point"] = f"{(all_pt + amount):.2f}"
    if tx_data:
        db[uid]["transaction"].append(tx_data)
        
    save_user_db(db)
    return new_pt

# --- Modal เติมซองอั่งเปา ---
class TopupGiftModal(discord.ui.Modal, title="เติมเงินผ่านซองของขวัญ TrueMoney"):
    gift_link = discord.ui.TextInput(
        label="ลิงก์ซองของขวัญ",
        placeholder="https://gift.truemoney.com/campaign/?v=xxxxxxxx",
        required=True
    )

    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        link = self.gift_link.value.strip()

        payload = {
            "phone": TRUEMONEY_PHONE,
            "gift_link": link,
            "keyapi": PLANARIA_API_KEY
        }
        headers = {"Content-Type": "application/json"}

        try:
            async with aiohttp.ClientSession() as session:
                async with session.post("https://www.planariashop.com/api/truewallet.php", json=payload, headers=headers) as resp:
                    res_data = await resp.json()
        except Exception as e:
            return await interaction.followup.send(f"{EMOJI_FAIL} เชื่อมต่อเซิร์ฟเวอร์ปลายทางไม่สำเร็จ: {e}", ephemeral=True)

        if res_data and res_data.get("status") == "success":
            amount = float(res_data.get("amount", 0))
            new_tx = {
                "topup": {
                    "name": "เติมผ่านซองอั๋งเปา",
                    "url": link,
                    "amount": amount,
                    "time": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    "phone": res_data.get("phone", "")
                }
            }
            new_bal = update_user_balance(interaction.user.id, amount, new_tx)

            # แจ้งเตือนผู้ใช้
            await interaction.followup.send(
                embed=discord.Embed(
                    description=f"{EMOJI_SUCCESS} เติมเงินสำเร็จจำนวน **{amount:,.2f}** บาท!\nยอดคงเหลือปัจจุบัน: `{new_bal:,.2f}` บาท",
                    color=discord.Color.green()
                ),
                ephemeral=True
            )

            # ส่ง Log
            log_channel = interaction.client.get_channel(TOPUP_LOG_CHANNEL_ID)
            if log_channel:
                log_embed = discord.Embed(
                    title=f"{EMOJI_BANK} บันทึกการเติมเงิน (ซองของขวัญ)",
                    description=(
                        f"{EMOJI_SUCCESS} **สถานะ:** สำเร็จ\n"
                        f"👤 **ผู้เติม:** {interaction.user.mention} (`{interaction.user.id}`)\n"
                        f"{EMOJI_POINT} **จำนวนเงิน:** `{amount:,.2f}` บาท\n"
                        f"{EMOJI_GIFT} **ลิงก์:** `{link}`"
                    ),
                    color=discord.Color.gold(),
                    timestamp=discord.utils.utcnow()
                )
                if interaction.user.display_avatar:
                    log_embed.set_thumbnail(url=interaction.user.display_avatar.url)
                await log_channel.send(embed=log_embed)
        else:
            msg = res_data.get("message", "ลิงก์ซองไม่ถูกต้อง หรือถูกใช้งานไปแล้ว")
            await interaction.followup.send(f"{EMOJI_FAIL} เติมเงินไม่สำเร็จ: {msg}", ephemeral=True)

class TopupPanelButtonView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="เติมเงินด้วยซองของขวัญ", style=discord.ButtonStyle.success, emoji="🧧", custom_id="btn_open_topup_gift")
    async def open_modal(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_modal(TopupGiftModal())

    @discord.ui.button(label="ช่องทางโอนเงิน (ธนาคาร)", style=discord.ButtonStyle.primary, emoji="🏦", custom_id="btn_view_bank_info")
    async def view_bank_info(self, interaction: discord.Interaction, button: discord.ui.Button):
        embed = discord.Embed(
            title="🏦 ข้อมูลบัญชีสำหรับโอนเงิน",
            description=(
                f"**ธนาคาร:** {BANK_NAME}\n"
                f"**เลขที่บัญชี:** `{BANK_ACCOUNT_NUMBER}`\n"
                f"**ชื่อบัญชี:** `{BANK_ACCOUNT_NAME}`\n\n"
                f"⚠️ *เมื่อโอนแล้ว ให้อัปโหลดรูปสลิปในห้อง <#{CHANNEL_SCAN_QR}> เพื่อรับเงินทันที*"
            ),
            color=discord.Color.blue()
        )
        if BANK_QR_IMAGE_URL:
            embed.set_image(url=BANK_QR_IMAGE_URL)

        await interaction.response.send_message(embed=embed, ephemeral=True)


# --- รวม Cog คำสั่ง Admin และ Event สแกน QR ---
class TopupAndAdminCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    def is_admin(self, user_id: int) -> bool:
        return user_id in ALLOWED_ADMIN_IDS

    # --- 1. คำสั่งติดตั้งพาเนลเติมเงิน (Admin Only) ---
    @app_commands.command(name="setup_topup", description="ติดตั้งข้อความแผงเติมเงินซองอั่งเปา (Admin)")
    async def setup_topup(self, interaction: discord.Interaction):
        if not self.is_admin(interaction.user.id):
            return await interaction.response.send_message(f"{EMOJI_FAIL} คุณไม่มีสิทธิ์ใช้งานคำสั่งนี้", ephemeral=True)

        embed = discord.Embed(
            title=f"{EMOJI_BANK} ช่องทางการเติมเงินเข้าสู่ระบบ",
            description=(
                f"1. **สลิปธนาคาร (QR Scan)**: อัปโหลดรูปสลิปในห้อง <#{CHANNEL_SCAN_QR}> ระบบจะตรวจสอบยอดให้อัตโนมัติ\n"
                f"2. **ซองอั่งเปา TrueMoney**: กดปุ่มด้านล่างเพื่อกรอกลิงก์ซองของขวัญ\n\n"
                f"{EMOJI_POINT} *ยอดเงินจะถูกเพิ่มเข้ากระเป๋าของคุณทันที (ค่าทำเนียม 0.1 บาท)*"
            ),
            color=discord.Color.green()
        )
        embed.set_image(url="https://cdn.discordapp.com/attachments/1530906838579548253/1560251203470753822/354cc291ee5fc86f.png?ex=6ad208aa&is=6ad0b72a&hm=bbe8951123f3aeac53475491ab19bae30584cce1921315d350b070193ee01b24")
        await interaction.channel.send(embed=embed, view=TopupPanelButtonView())
        await interaction.response.send_message(f"{EMOJI_SUCCESS} ติดตั้งแผงเติมเงินเรียบร้อยแล้ว", ephemeral=True)

    # --- 2. คำสั่งจัดการแต้ม (Admin Points System) ---
    @app_commands.command(name="point_check", description="เช็คพ้อยท์ของผู้ใช้งาน")
    @app_commands.describe(member="ผู้ใช้ที่ต้องการตรวจสอบ")
    async def point_check(self, interaction: discord.Interaction, member: discord.Member):
        db = get_user_db()
        user_info = db.get(str(member.id), {})
        pt = float(user_info.get("point", 0))
        all_pt = float(user_info.get("all-point", 0))

        embed = discord.Embed(title=f"{EMOJI_POINT} ข้อมูลพ้อยท์ของผู้ใช้", color=discord.Color.blue())
        embed.set_thumbnail(url=member.display_avatar.url if member.display_avatar else None)
        embed.add_field(name="ผู้ใช้งาน", value=f"{member.mention} (`{member.id}`)", inline=False)
        embed.add_field(name="พ้อยท์คงเหลือ", value=f"`{pt:,.2f}` บาท", inline=True)
        embed.add_field(name="ยอดเติมสะสม", value=f"`{all_pt:,.2f}` บาท", inline=True)
        await interaction.response.send_message(embed=embed, ephemeral=True)

    @app_commands.command(name="point_set", description="กำหนดแต้มของผู้ใช้งาน (Admin)")
    @app_commands.describe(member="ผู้ใช้งาน", amount="จำนวนพ้อยท์ใหม่ที่ต้องการกำหนด")
    async def point_set(self, interaction: discord.Interaction, member: discord.Member, amount: float):
        if not self.is_admin(interaction.user.id):
            return await interaction.response.send_message(f"{EMOJI_FAIL} คุณไม่มีสิทธิ์ใช้งานคำสั่งนี้", ephemeral=True)

        db = get_user_db()
        uid = str(member.id)
        if uid not in db:
            db[uid] = {"userId": member.id, "point": "0.0", "all-point": "0.0", "historybuy": [], "transaction": [], "buyrole": [], "buymarket": []}
        
        db[uid]["point"] = f"{amount:.2f}"
        save_user_db(db)

        await interaction.response.send_message(
            f"{EMOJI_SUCCESS} ทำการกำหนดแต้มของ {member.mention} เป็น `{amount:,.2f}` เรียบร้อยแล้ว",
            ephemeral=True
        )

    @app_commands.command(name="point_add", description="เพิ่มพ้อยท์ให้ผู้ใช้งาน (Admin)")
    @app_commands.describe(member="ผู้ใช้งาน", amount="จำนวนพ้อยท์ที่ต้องการเพิ่ม")
    async def point_add(self, interaction: discord.Interaction, member: discord.Member, amount: float):
        if not self.is_admin(interaction.user.id):
            return await interaction.response.send_message(f"{EMOJI_FAIL} คุณไม่มีสิทธิ์ใช้งานคำสั่งนี้", ephemeral=True)

        new_bal = update_user_balance(member.id, amount)
        await interaction.response.send_message(
            f"{EMOJI_SUCCESS} เติมแต้มให้ {member.mention} จำนวน `+{amount:,.2f}` สำเร็จ! ยอดคงเหลือ: `{new_bal:,.2f}`",
            ephemeral=True
        )

    # --- 3. ระบบตรวจสลิปอัตโนมัติ (on_message QR Scan) ---
    @commands.Cog.listener()
    async def on_message(self, message: discord.Message):
        if message.author.bot or message.channel.id != CHANNEL_SCAN_QR:
            return

        if not message.attachments:
            return

        os.makedirs("qrdata", exist_ok=True)

        for attachment in message.attachments:
            if not any(attachment.filename.lower().endswith(ext) for ext in [".png", ".jpg", ".jpeg"]):
                continue

            img_bytes = await attachment.read()
            nparr = np.frombuffer(img_bytes, np.uint8)
            img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)

            # ใช้ OpenCV QRCodeDetector แทน pyzbar (รองรับบน Bot-Hosting 100%)
            detector = cv2.QRCodeDetector()
            qr_data, _, _ = detector.detectAndDecode(img)

            if not qr_data:
                await message.channel.send(
                    embed=discord.Embed(description=f"{EMOJI_FAIL} ไม่พบ QR Code บนสลิป กรุณาถ่ายภาพให้คมชัด", color=discord.Color.red())
                )
                continue

            qr_file = f"qrdata/{qr_data}.txt"
            # ... โค้ดส่วนที่เหลือทำงานต่อปกติ ...

            if os.path.exists(qr_file):
                await message.channel.send(
                    embed=discord.Embed(description=f"{EMOJI_FAIL} สลิปนี้ถูกใช้งานไปแล้ว!", color=discord.Color.red())
                )
                continue

            temp_msg = await message.channel.send(
                embed=discord.Embed(description=f"{EMOJI_WAIT} กำลังส่งข้อมูลตรวจสลิป...", color=discord.Color.blue())
            )

            # ยิง API เช็คสลิป PlanariaShop
            payload = {
                "keyapi": PLANARIA_API_KEY,
                "qrcode_text": qr_data
            }
            try:
                async with aiohttp.ClientSession() as session:
                    async with session.post("https://www.planariashop.com/api/checkslip.php", json=payload) as resp:
                        res = await resp.json()
            except Exception as e:
                await temp_msg.edit(embed=discord.Embed(description=f"{EMOJI_FAIL} เชื่อมต่อระบบสลิปขัดข้อง: {e}", color=discord.Color.red()))
                continue

            if res.get("status") == "success":
                receiver_name = res.get("receiver", {}).get("name", "")
                bank_code = res.get("receiver", {}).get("bank_code") or res.get("receiver", {}).get("receiver_code")

                # ตรวจชื่อผู้รับ
                if RECEIVER_NAME_CHECK and RECEIVER_NAME_CHECK not in receiver_name:
                    await temp_msg.edit(embed=discord.Embed(description=f"{EMOJI_FAIL} ชื่อผู้รับไม่ถูกต้อง ({receiver_name})", color=discord.Color.red()))
                    continue

                # บันทึกกันสลิปซ้ำ
                with open(qr_file, "w", encoding="utf-8") as f:
                    f.write(qr_data)

                amount = float(res.get("amount", 0))
                sender = res.get("sender", {}).get("name", "")
                bank_name = res.get("sender", {}).get("bank_name", "")

                new_tx = {
                    "topup": {
                        "name": "เติมผ่านธนาคาร",
                        "url": qr_data,
                        "amount": amount,
                        "sender": f"{sender} / {bank_name}",
                        "time": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                        "sliptime": res.get("slip_time", "")
                    }
                }
                new_bal = update_user_balance(message.author.id, amount, new_tx)

                await temp_msg.edit(
                    embed=discord.Embed(
                        description=f"{EMOJI_SUCCESS} ตรวจสอบสำเร็จ! เติมเงินจำนวน **{amount:,.2f}** บาท ให้ <@{message.author.id}>\nยอดคงเหลือ: `{new_bal:,.2f}` บาท",
                        color=discord.Color.green()
                    )
                )

                # ส่ง Log
                log_channel = self.bot.get_channel(TOPUP_LOG_CHANNEL_ID)
                if log_channel:
                    log_embed = discord.Embed(
                        title=f"{EMOJI_BANK} บันทึกการเติมเงิน (สลิปธนาคาร)",
                        description=(
                            f"{EMOJI_SUCCESS} **สถานะ:** เติมเงินสำเร็จ\n"
                            f"👤 **ผู้เติม:** {message.author.mention}\n"
                            f"{EMOJI_POINT} **จำนวนเงิน:** `{amount:,.2f}` บาท\n"
                            f"🏦 **ผู้โอน:** {sender} ({bank_name})\n"
                            f"```{qr_data}```"
                        ),
                        color=discord.Color.green(),
                        timestamp=discord.utils.utcnow()
                    )
                    if message.author.display_avatar:
                        log_embed.set_thumbnail(url=message.author.display_avatar.url)
                    await log_channel.send(embed=log_embed)
            else:
                await temp_msg.edit(
                    embed=discord.Embed(
                        description=f"{EMOJI_FAIL} ไม่พบข้อมูลสลิปนี้ในระบบ หรือ QR ไม่ถูกต้อง",
                        color=discord.Color.red()
                    )
                )
async def setup(bot: commands.Bot):
    bot.add_view(TopupPanelButtonView())
    await bot.add_cog(TopupAndAdminCog(bot))